---
title: Tiệm chữ cuối hẻm
date: 2026-09-12
category: Ở Sài Gòn
excerpt: Cuối hẻm có một tiệm photocopy không biển hiệu. Giấy còn ấm, chữ chưa kịp nguội, cửa mở suốt buổi chiều.
cover: tea
imageAlt: Cửa tiệm photocopy cuối hẻm lúc nắng chiều
readingMinutes: 6
---

Cuối hẻm không có biển. Chỉ một cánh cửa sắt kéo lên, một vệt nắng cắt ngang nền gạch, và mùi giấy nóng. Người trong xóm gọi là tiệm chữ. Đủ rồi.

Tôi đến khi cần in vài trang, đôi khi chỉ để đứng trong khoảng mát ấy năm phút. Thành phố ra ngoài. Trong này, máy kêu đều như thở.

![Cửa tiệm lúc nắng xế, xe máy dựng sát tường](img/tiem-chu-cuoi-hem-hem.jpg)

## Giấy còn ấm

Chủ tiệm không hỏi nhiều. Đưa file, hoặc đưa một tờ đã nhăn. Ông đặt lên kính, đậy nắp, nhấn. Máy thở ra một tờ mới, mép còn cong vì nhiệt. Chữ trên đó chưa kịp nguội.

Tôi hay để tay lên mặt giấy. Ấm. Cùng một câu, bản in đầu và bản in thứ ba vẫn khác nhau một chút — đậm hơn, hoặc lệch nửa milimét. Ông không xin lỗi. Ông nói: máy cũ thì có tính.

![Khay giấy bắt nắng cửa](img/tiem-chu-cuoi-hem-giay.jpg)
![Tờ vừa ra, còn cong vì nhiệt](img/tiem-chu-cuoi-hem-may.jpg)

Chữ trên màn hình thì phẳng. Chữ trên giấy thì có chỗ ngồi. Có trọng lượng. Có thể gấp, có thể làm mất, có thể để trong sổ rồi quên cho đến khi một buổi khác cần đến.

> In xong rồi về — câu ấy, ở đây, không phải đuổi khách. Là phép lịch sự của người biết việc mình vừa làm ra một vật.

## Cửa mở suốt chiều

Hẻm hẹp. Nắng vào được một lát rồi đi. Ông không kéo cửa. Muỗi, bụi, tiếng xe, hết thảy được phép vào, miễn máy còn chạy.

Tôi thích đứng nhìn ra từ trong. Trong tối, ngoài sáng. Một chậu cây, một vệt tường bong, một chiếc xe dựng. Không cần biển hiệu. Người cần chữ thì tìm được.

---

Trang này cũng vậy. Mỗi bài là một file, mỗi ảnh là một đường dẫn. Không có CMS kéo thả. Chỉ có giấy — dù giấy ấy đang nằm trong một thư mục tên `img`.

Nếu mai tôi in bài này ở tiệm cuối hẻm, tờ giấy sẽ ấm. Chữ sẽ lệch một chút. Tôi sẽ để tay lên, rồi gấp bỏ túi.
