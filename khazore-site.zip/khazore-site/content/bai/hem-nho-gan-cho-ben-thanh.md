---
title: Hẻm nhỏ gần chợ Bến Thành
date: 2026-08-21
category: Ở Sài Gòn
excerpt: Trong hẻm, thời gian đi chậm hơn ngoài đường. Người ta bán chè, sửa xe, phơi áo. Tôi hay đứng đó một lúc trước khi đi tiếp.
cover: moss
imageAlt: Hẻm phố Việt Nam với đèn và nhà ống
readingMinutes: 5
---

Từ Lê Thánh Tôn rẽ vào, tiếng xe giảm đi một nửa. Hẻm đủ rộng cho một xe máy và một người đi bộ, nếu cả hai biết nhường.

Nhà ống hai bên, ban công phơi khăn. Một quán chè không biển hiệu, chỉ có mấy ghế nhựa và nồi trên bếp than. Bà chủ nhớ tôi uống chè đậu xanh ít đường.

Tôi không chụp ảnh hẻm này. Mỗi lần giơ máy, nó thành cảnh. Khi không giơ máy, nó chỉ là chỗ người ta sống — và sống thì không cần khung hình.

Sài Gòn hay bị kể bằng phố lớn, bảng đèn, kẹt xe. Nhưng thành phố này giữ mình trong những đoạn không có tên trên bản đồ du lịch. Hẻm là chỗ đó.
