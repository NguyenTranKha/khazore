---
title: Chữ serif và sự chậm rãi
date: 2026-06-29
category: Thiết kế
excerpt: Serif không chỉ là chân chữ. Nó là cách nói: hãy đọc chậm, như người ta từng đọc trên giấy.
cover: tea
imageAlt: Chữ đúc chì và bản in thử trên giấy
readingMinutes: 7
---

Sans-serif tiện. Nó sạch, hiện đại, hợp nút bấm và bảng điều khiển. Tôi dùng nó cho giao diện. Nhưng khi ngồi đọc một bài dài, tôi muốn serif.

Chân chữ là điểm tựa cho mắt, kéo mình từ chữ này sang chữ kia. Trên giấy, điều đó đã được kiểm chứng vài trăm năm. Trên màn hình, người ta từng sợ serif mờ. Màn hình bây giờ đủ nét. Cái sợ ấy hết hạn.

Chọn font là chọn tốc độ. Một tiêu đề Grotesk lớn nói: nhìn đây, mau. Một tiêu đề serif vừa phải nói: vào đây, ở lại. Nguyễn Trần Kha chọn cái sau — không vì cũ, vì hợp với việc viết chậm.

Tôi không chống sans. Chỉ chống việc mặc định rằng mọi thứ phải cùng một họ chữ, cùng một nhịp. Trang đọc không phải bảng điều khiển. Nó là chỗ ngồi.
