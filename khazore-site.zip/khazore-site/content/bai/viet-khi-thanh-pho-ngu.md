---
title: Viết khi thành phố ngủ
date: 2026-07-11
category: Ghi chép
excerpt: Nửa đêm, máy lạnh kêu nhỏ. Tôi mở sổ. Những câu ban ngày không dám viết thì ban đêm tự đến.
cover: clay
imageAlt: Bàn viết ban đêm dưới ánh đèn
readingMinutes: 5
---

Ban ngày chữ bị cắt ngang. Chuông, tin nhắn, việc phải trả lời. Ban đêm thì ít người đòi mình hơn.

Tôi không phải người thức khuya vì phong cách. Chỉ là sau mười một giờ, đầu bớt cãi. Câu nào ban trưa còn vòng vo thì lúc này đi thẳng.

Đèn bàn, một ly nước, điện thoại úp sấp. Không nhạc — nhạc hay kéo mình đi chỗ khác. Tiếng máy lạnh đủ để không im tuyệt đối, đủ để không phải nghĩ.

Sáng hôm sau đọc lại, đôi khi thấy vụng. Không sao. Đêm không phải lúc sửa. Đêm là lúc cho chữ ra. Sửa là việc của ánh sáng.
