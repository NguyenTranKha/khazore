---
title: Khoảng trắng cũng là thiết kế
date: 2026-08-07
category: Thiết kế
excerpt: Một trang đẹp không phải vì nhồi chữ. Nó đẹp vì biết để yên những chỗ trống, để mắt có chỗ nghỉ.
cover: pine
imageAlt: Bàn làm việc gọn, giấy và tách cà phê
readingMinutes: 7
---

Người mới học thiết kế hay sợ chỗ trống. Trống thì phí. Trống thì như chưa xong. Họ nhét icon, nhét màu, nhét chữ cho đầy — rồi lạ là không ai muốn đọc.

Khoảng trắng không phải sự vắng mặt. Nó là nhịp. Như nghỉ trong nhạc. Bỏ nghỉ đi, bản nhạc thành tiếng ồn.

Tôi nhìn báo giấy cũ: cột hẹp, lề rộng, tiêu đề không cần bóng. Mắt biết đi đâu vì trang biết im. Màn hình hiện đại làm ngược lại — mọi thứ cùng kêu, cùng lúc.

Khi làm một trang, tôi hỏi: cái này có cần không? Nếu xóa đi mà ý vẫn rõ, thì xóa. Cái còn lại mới là thiết kế. Phần bỏ đi cũng vậy.
