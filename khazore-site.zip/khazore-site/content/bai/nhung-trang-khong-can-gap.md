---
title: Những trang không cần gấp
date: 2026-07-30
category: Đọc
excerpt: Có những đoạn văn tôi đọc ba lần. Không phải vì khó. Vì muốn ở lại thêm một chút, như đứng trước cửa sổ mưa.
cover: ink
imageAlt: Sách mở trên đùi, ánh sáng dịu
readingMinutes: 4
---

Không phải trang nào cũng đáng gấp góc. Có trang chỉ để đi qua, như hành lang dẫn tới một căn phòng.

Rồi có trang làm mình ngừng. Không phải vì câu hay theo kiểu trích dẫn. Vì nó nói đúng một việc mình chưa biết cách nói. Lúc đó tôi không gấp. Tôi để sách mở, nhìn ra ngoài.

Những trang ấy không cần đánh dấu. Chúng tự tìm lại mình, vài tháng sau, khi một việc xảy ra giống như trong sách. Đọc không phải để nhớ — để nhận ra.

Tôi giữ một chồng sách nhỏ trên bàn. Không quá mười cuốn. Đủ để thỉnh thoảng cầm lên, mở đúng chỗ cũ, đọc lại đoạn không cần gấp.
