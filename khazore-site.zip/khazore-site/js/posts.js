(() => {
  const esc = (s) => String(s)
    .replace(/&/g, "&")
    .replace(/</g, "<")
    .replace(/>/g, ">")
    .replace(/"/g, """);
  const dateLabel = (iso) => {
    const [y, m, d] = iso.split("-").map(Number);
    return d + " tháng " + m + ", " + y;
  };
  const cover = (post) =>
    '<div class="cover cover--' + esc(post.cover) + '"><img src="img/' + esc(post.slug) + '.jpg" alt="' + esc(post.imageAlt) + '" width="1400" height="788" /></div>';

  fetch("posts.json")
    .then((r) => r.json())
    .then((posts) => {
      const featured = posts.find((p) => p.featured) || posts[0];
      const featuredRoot = document.getElementById("featured-root");
      if (featured && featuredRoot) {
        featuredRoot.hidden = false;
        featuredRoot.innerHTML =
          '<p class="kicker">Bài nổi bật</p><article>' +
          '<a class="cover-btn" href="bai/' + esc(featured.slug) + '.html" aria-label="Đọc bài: ' + esc(featured.title) + '">' + cover(featured) + "</a>" +
          '<div class="measure featured__copy">' +
          '<h3 class="featured__title"><a class="title-link" href="bai/' + esc(featured.slug) + '.html">' + esc(featured.title) + "</a></h3>" +
          '<p class="featured__excerpt">' + esc(featured.excerpt) + "</p>" +
          '<p class="featured__meta"><span class="meta-accent">' + esc(featured.category) + "</span> · <time datetime='" + featured.date + "'>" + dateLabel(featured.date) + "</time> · " + featured.readingMinutes + " phút đọc</p>" +
          "</div></article>";
      }
      const listing = posts.filter((p) => p.slug !== featured?.slug);
      const root = document.getElementById("posts-root");
      if (root) {
        root.innerHTML = listing
          .map(
            (post) =>
              '<li data-category="' + esc(post.category) + '"><article class="card">' +
              '<a class="cover-btn" href="bai/' + esc(post.slug) + '.html" aria-label="Đọc bài: ' + esc(post.title) + '">' + cover(post) + "</a>" +
              '<h3 class="card__title"><a class="title-link" href="bai/' + esc(post.slug) + '.html">' + esc(post.title) + "</a></h3>" +
              '<p class="card__excerpt">' + esc(post.excerpt) + "</p>" +
              '<p class="card__meta"><span class="meta-accent">' + esc(post.category) + "</span> · <time datetime='" + post.date + "'>" + dateLabel(post.date) + "</time></p>" +
              "</article></li>",
          )
          .join("");
      }
      const cats = [...new Set(posts.map((p) => p.category))];
      const topics = document.getElementById("topics-root");
      if (topics) {
        topics.innerHTML = cats
          .map((name) => '<li><button type="button" class="tag" data-topic="' + esc(name) + '">' + esc(name) + "</button></li>")
          .join("");
      }
      const items = [...(root?.querySelectorAll("li") || [])];
      const heading = document.getElementById("bai-moi-heading");
      const clear = document.getElementById("clear-topic");
      let current = null;
      function apply(topic) {
        current = topic;
        items.forEach((li) => {
          li.hidden = Boolean(topic) && li.dataset.category !== topic;
        });
        document.querySelectorAll(".tag").forEach((btn) => {
          btn.classList.toggle("is-active", btn.dataset.topic === topic);
        });
        if (heading) heading.textContent = topic || "Bài mới";
        if (clear) clear.hidden = !topic;
      }
      document.querySelectorAll(".tag[data-topic]").forEach((btn) => {
        btn.addEventListener("click", () => apply(current === btn.dataset.topic ? null : btn.dataset.topic));
      });
      clear?.addEventListener("click", () => apply(null));
    })
    .catch((err) => console.error(err));
})();
