#!/usr/bin/env node
/**
 * Chỉ thêm / cập nhật bài từ Markdown.
 * Không ghi đè index.html, css, js nếu file đã có.
 *
 *   node them-bai.mjs              # bài mới hoặc .md đổi
 *   node them-bai.mjs --all        # dựng lại mọi bai/*.html, vẫn không đụng index
 *   node them-bai.mjs --slug ten   # chỉ một bài
 */
import {
  existsSync,
  mkdirSync,
  readdirSync,
  readFileSync,
  writeFileSync,
  copyFileSync,
  statSync,
  cpSync,
} from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = existsSync(join(HERE, "content/bai")) ? HERE : join(HERE, "..");
const CONTENT = join(ROOT, "content/bai");
const IMG_SRC = existsSync(join(ROOT, "public/img"))
  ? join(ROOT, "public/img")
  : join(ROOT, "img");

function resolveOut() {
  if (process.env.OUT) {
    return process.env.OUT.startsWith("/")
      ? process.env.OUT
      : join(process.cwd(), process.env.OUT);
  }
  return existsSync(join(HERE, "content/bai")) ? HERE : join(ROOT, "gh-pages");
}

const OUT = resolveOut();
const SEPARATE = resolve(OUT) !== resolve(ROOT);

const args = new Set(process.argv.slice(2));
const forceAll = args.has("--all");
const slugFlag = process.argv.includes("--slug")
  ? process.argv[process.argv.indexOf("--slug") + 1]
  : null;

function parseFrontmatter(raw) {
  const text = raw.replace(/^\uFEFF/, "").replace(/\r\n/g, "\n");
  if (!text.startsWith("---\n")) return { data: {}, body: text.trim() };
  const end = text.indexOf("\n---\n", 4);
  if (end === -1) return { data: {}, body: text.trim() };
  const yaml = text.slice(4, end);
  const body = text.slice(end + 5).trim();
  const data = {};
  for (const line of yaml.split("\n")) {
    const cut = line.indexOf(":");
    if (cut <= 0) continue;
    const key = line.slice(0, cut).trim();
    let value = line.slice(cut + 1).trim();
    if (
      (value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))
    ) {
      value = value.slice(1, -1);
    }
    if (value === "true") data[key] = true;
    else if (value === "false") data[key] = false;
    else if (/^\d+$/.test(value)) data[key] = Number(value);
    else data[key] = value;
  }
  return { data, body };
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, "\u0026amp;")
    .replace(/</g, "\u0026lt;")
    .replace(/>/g, "\u0026gt;")
    .replace(/"/g, "\u0026quot;");
}

function inlineMd(text) {
  return escapeHtml(text)
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/\*(.+?)\*/g, "<em>$1</em>")
    .replace(
      /\[([^\]]+)\]\((https?:\/\/[^\s)]+|\/[^\s)]+|#[^\s)]+)\)/g,
      '<a class="title-link" href="$2">$1</a>',
    );
}

function figureHtml(alt, src) {
  const file = src.replace(/^\.\//, "").replace(/^img\//, "").replace(/^\/img\//, "");
  const href = `../img/${file}`;
  const cap = alt ? `<figcaption>${escapeHtml(alt)}</figcaption>` : "";
  return `<figure class="md-figure__item"><img src="${href}" alt="${escapeHtml(alt)}" loading="lazy" />${cap}</figure>`;
}

function mdToHtml(md) {
  return md
    .trim()
    .split(/\n{2,}/)
    .map((block) => {
      const lines = block.split("\n").filter((l) => l.trim());
      const imgRe = /^!\[([^\]]*)\]\(([^)]+)\)$/;
      if (lines.length && lines.every((line) => imgRe.test(line))) {
        const figs = lines.map((line) => {
          const m = line.match(imgRe);
          return figureHtml(m[1], m[2]);
        });
        const cls = figs.length > 1 ? "md-figure md-figure--pair" : "md-figure";
        return `<div class="${cls}">${figs.join("")}</div>`;
      }
      if (block.trim() === "---" || block.trim() === "***") return '<hr class="md-rule" />';
      if (lines.every((line) => /^[-*]\s+/.test(line))) {
        return `<ul class="md-list">${lines
          .map((line) => `<li>${inlineMd(line.replace(/^[-*]\s+/, ""))}</li>`)
          .join("")}</ul>`;
      }
      if (/^##\s+/.test(block)) return `<h2>${inlineMd(block.replace(/^##\s+/, ""))}</h2>`;
      if (/^#\s+/.test(block)) return `<h2>${inlineMd(block.replace(/^#\s+/, ""))}</h2>`;
      if (lines.every((line) => /^>\s?/.test(line))) {
        return `<blockquote>${inlineMd(lines.map((l) => l.replace(/^>\s?/, "")).join(" "))}</blockquote>`;
      }
      return `<p>${inlineMd(block.split("\n").join(" "))}</p>`;
    })
    .join("");
}

function countWords(markdown) {
  const plain = markdown.replace(/[#>*_`[\]]/g, " ").replace(/\s+/g, " ").trim();
  return plain ? plain.split(" ").length : 0;
}

function formatDateLabel(iso) {
  const [year, month, day] = iso.split("-").map(Number);
  return `${day} tháng ${month}, ${year}`;
}

function loadPosts() {
  return readdirSync(CONTENT)
    .filter((f) => f.endsWith(".md") && !f.startsWith("_"))
    .map((file) => {
      const path = join(CONTENT, file);
      const raw = readFileSync(path, "utf8");
      const { data, body } = parseFrontmatter(raw);
      const slug = String(data.slug ?? file.replace(/\.md$/, ""));
      const override = typeof data.readingMinutes === "number" ? data.readingMinutes : 0;
      return {
        slug,
        title: String(data.title ?? slug),
        date: String(data.date ?? "1970-01-01"),
        category: String(data.category ?? "Ghi chép"),
        excerpt: String(data.excerpt ?? ""),
        cover: String(data.cover ?? "clay"),
        imageAlt: String(data.imageAlt ?? data.title ?? slug),
        featured: data.featured === true,
        readingMinutes: override || Math.max(1, Math.round(countWords(body) / 80)),
        body,
        mdPath: path,
        mdMtime: statSync(path).mtimeMs,
      };
    })
    .sort((a, b) => b.date.localeCompare(a.date) || a.title.localeCompare(b.title));
}

function newerThan(srcMs, destPath) {
  if (!existsSync(destPath)) return true;
  return srcMs > statSync(destPath).mtimeMs;
}

function writeIfMissing(path, content) {
  if (existsSync(path)) return false;
  mkdirSync(dirname(path), { recursive: true });
  writeFileSync(path, content);
  return true;
}

const THEME_ICONS = `<svg class="icon-sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 3v1.5M12 19.5V21M4.93 4.93l1.06 1.06M18.01 18.01l1.06 1.06M3 12h1.5M19.5 12H21M4.93 19.07l1.06-1.06M18.01 5.99l1.06-1.06"/></svg>
<svg class="icon-moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M21 14.5A8.5 8.5 0 1 1 9.5 3 7 7 0 0 0 21 14.5z"/></svg>`;

function pageShell({ prefix, title, description, extraScripts, main }) {
  return `<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>${escapeHtml(title)}</title>
<meta name="description" content="${escapeHtml(description)}" />
<meta name="theme-color" content="#F6F3EE" />
<link rel="icon" type="image/svg+xml" href="${prefix}favicon.svg" />
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,500;1,9..144,500&family=Source+Sans+3:ital,wght@0,400;0,500;1,400&display=swap" />
<link rel="stylesheet" href="${prefix}css/styles.css" />
<script>(function(){try{var t=localStorage.getItem("khazore-theme");if(t!=="dark"&&t!=="light"){t=window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light";}document.documentElement.setAttribute("data-theme",t);}catch(e){document.documentElement.setAttribute("data-theme","light");}})();</script>
</head>
<body>
<header class="site-header">
  <a class="sr-only" href="#noi-dung">Bỏ qua đến nội dung</a>
  <div class="wrap site-header__inner">
    <a class="logo title-link" href="${prefix}index.html">Nguyễn Trần Kha</a>
    <nav class="nav" aria-label="Chính"><ul>
      <li><a class="title-link" href="${prefix}index.html#bai-viet">Viết</a></li>
      <li class="nav-optional"><a class="title-link" href="${prefix}index.html#chu-de">Chủ đề</a></li>
      <li class="nav-optional"><a class="title-link" href="${prefix}index.html#ve-toi">Về tôi</a></li>
    </ul></nav>
    <button type="button" class="theme-toggle" data-theme-toggle aria-label="Chuyển sang giao diện tối">${THEME_ICONS}</button>
  </div>
</header>
<main id="noi-dung">
${main}
</main>
<footer class="site-footer">
  <div class="wrap site-footer__inner">
    <p>© 2026 Nguyễn Trần Kha</p>
    <ul>
      <li><a class="title-link" href="${prefix}index.html#chu-de">Chủ đề</a></li>
      <li><a class="title-link" href="${prefix}index.html#ve-toi">Về tôi</a></li>
      <li><a class="title-link" href="${prefix}index.html#colophon">Colophon</a></li>
    </ul>
  </div>
</footer>
<script src="${prefix}js/theme.js"></script>
${extraScripts}
</body>
</html>
`;
}

function defaultIndex() {
  return pageShell({
    prefix: "",
    title: "Nguyễn Trần Kha",
    description: "Viết chậm về những thứ đáng nhớ. Một góc viết từ Sài Gòn.",
    extraScripts: '<script src="js/posts.js"></script>',
    main: `<section class="hero wrap">
<p class="hero__line">Viết chậm về những thứ đáng nhớ</p>
<p class="hero__dek">Một góc viết từ Sài Gòn. Ít bài, đọc chậm, không vội xuất bản cho đủ lịch.</p>
</section>
<section class="featured wrap" id="featured-root" hidden></section>
<section id="bai-viet" class="posts wrap" aria-labelledby="bai-moi-heading">
<div class="posts__head">
<h2 id="bai-moi-heading" class="kicker">Bài mới</h2>
<button type="button" class="posts__all title-link" id="clear-topic" hidden>Xem tất cả</button>
</div>
<ul class="grid" id="posts-root"></ul>
</section>
<section id="chu-de" class="topics wrap" aria-labelledby="chu-de-heading">
<h2 id="chu-de-heading" className="kicker">Chủ đề</h2>
<ul class="tags" id="topics-root"></ul>
</section>
<section id="ve-toi" class="about wrap" aria-labelledby="ve-toi-heading">
<div class="about__inner">
<h2 id="ve-toi-heading" class="kicker">Về tôi</h2>
<p>Tôi viết từ Sài Gòn. Nguyễn Trần Kha là nơi giữ những bài không vội — ghi chép, đọc, phố, và vài suy nghĩ về chữ. Không newsletter, không quảng cáo. Chỉ trang này, khi có gì đáng nhớ.</p>
</div>
</section>
<section id="colophon" class="colophon wrap" aria-labelledby="colophon-heading">
<div class="colophon__inner">
<h2 id="colophon-heading" class="kicker">Colophon</h2>
<p>Chữ tiêu đề Fraunces, chữ bài Source Sans 3. Nền giấy ấm, accent xanh rêu. Danh sách bài lấy từ posts.json — sửa index.html thoải mái, thêm bài không đè khung trang.</p>
</div>
</section>`,
  }).replace('className="kicker"', 'class="kicker"');
}

function articleHtml(post) {
  return pageShell({
    prefix: "../",
    title: `${post.title} — Nguyễn Trần Kha`,
    description: post.excerpt,
    extraScripts: "",
    main: `<article class="article">
<a class="article__back title-link" href="../index.html">
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M19 12H5M11 18l-6-6 6-6"/></svg>
<span>Tất cả bài viết</span>
</a>
<p class="article__cat">${escapeHtml(post.category)}</p>
<h1 class="article__title">${escapeHtml(post.title)}</h1>
<p class="article__meta"><time datetime="${post.date}">${formatDateLabel(post.date)}</time> · ${post.readingMinutes} phút đọc</p>
<div class="cover cover--${escapeHtml(post.cover)}"><img src="../img/${post.slug}.jpg" alt="${escapeHtml(post.imageAlt)}" width="1400" height="788" /></div>
<div class="article__body measure">${mdToHtml(post.body)}</div>
</article>`,
  });
}

const POSTS_JS = `(() => {
  const esc = (s) => String(s)
    .replace(/&/g, "&")
    .replace(/</g, "<")
    .replace(/>/g, ">")
    .replace(/"/g, """);
  const dateLabel = (iso) => {
    const [y, m, d] = iso.split("-").map(Number);
    return d + " tháng " + m + ", " + y;
  };
  const cover = (post) =>
    '<div class="cover cover--' + esc(post.cover) + '"><img src="img/' + esc(post.slug) + '.jpg" alt="' + esc(post.imageAlt) + '" width="1400" height="788" /></div>';

  fetch("posts.json")
    .then((r) => r.json())
    .then((posts) => {
      const featured = posts.find((p) => p.featured) || posts[0];
      const featuredRoot = document.getElementById("featured-root");
      if (featured && featuredRoot) {
        featuredRoot.hidden = false;
        featuredRoot.innerHTML =
          '<p class="kicker">Bài nổi bật</p><article>' +
          '<a class="cover-btn" href="bai/' + esc(featured.slug) + '.html" aria-label="Đọc bài: ' + esc(featured.title) + '">' + cover(featured) + "</a>" +
          '<div class="measure featured__copy">' +
          '<h3 class="featured__title"><a class="title-link" href="bai/' + esc(featured.slug) + '.html">' + esc(featured.title) + "</a></h3>" +
          '<p class="featured__excerpt">' + esc(featured.excerpt) + "</p>" +
          '<p class="featured__meta"><span class="meta-accent">' + esc(featured.category) + "</span> · <time datetime='" + featured.date + "'>" + dateLabel(featured.date) + "</time> · " + featured.readingMinutes + " phút đọc</p>" +
          "</div></article>";
      }
      const listing = posts.filter((p) => p.slug !== featured?.slug);
      const root = document.getElementById("posts-root");
      if (root) {
        root.innerHTML = listing
          .map(
            (post) =>
              '<li data-category="' + esc(post.category) + '"><article class="card">' +
              '<a class="cover-btn" href="bai/' + esc(post.slug) + '.html" aria-label="Đọc bài: ' + esc(post.title) + '">' + cover(post) + "</a>" +
              '<h3 class="card__title"><a class="title-link" href="bai/' + esc(post.slug) + '.html">' + esc(post.title) + "</a></h3>" +
              '<p class="card__excerpt">' + esc(post.excerpt) + "</p>" +
              '<p class="card__meta"><span class="meta-accent">' + esc(post.category) + "</span> · <time datetime='" + post.date + "'>" + dateLabel(post.date) + "</time></p>" +
              "</article></li>",
          )
          .join("");
      }
      const cats = [...new Set(posts.map((p) => p.category))];
      const topics = document.getElementById("topics-root");
      if (topics) {
        topics.innerHTML = cats
          .map((name) => '<li><button type="button" class="tag" data-topic="' + esc(name) + '">' + esc(name) + "</button></li>")
          .join("");
      }
      const items = [...(root?.querySelectorAll("li") || [])];
      const heading = document.getElementById("bai-moi-heading");
      const clear = document.getElementById("clear-topic");
      let current = null;
      function apply(topic) {
        current = topic;
        items.forEach((li) => {
          li.hidden = Boolean(topic) && li.dataset.category !== topic;
        });
        document.querySelectorAll(".tag").forEach((btn) => {
          btn.classList.toggle("is-active", btn.dataset.topic === topic);
        });
        if (heading) heading.textContent = topic || "Bài mới";
        if (clear) clear.hidden = !topic;
      }
      document.querySelectorAll(".tag[data-topic]").forEach((btn) => {
        btn.addEventListener("click", () => apply(current === btn.dataset.topic ? null : btn.dataset.topic));
      });
      clear?.addEventListener("click", () => apply(null));
    })
    .catch((err) => console.error(err));
})();
`;

const THEME_JS = `(() => {
  const KEY = "khazore-theme";
  const root = document.documentElement;
  function apply(theme) {
    root.setAttribute("data-theme", theme);
    try { localStorage.setItem(KEY, theme); } catch (e) {}
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", theme === "dark" ? "#161412" : "#F6F3EE");
    document.querySelectorAll("[data-theme-toggle]").forEach((btn) => {
      btn.setAttribute("aria-label", theme === "dark" ? "Chuyển sang giao diện sáng" : "Chuyển sang giao diện tối");
    });
  }
  document.querySelectorAll("[data-theme-toggle]").forEach((btn) => {
    btn.addEventListener("click", () => {
      apply(root.getAttribute("data-theme") === "dark" ? "light" : "dark");
    });
  });
})();
`;

function copyOwned(rel) {
  const from = join(ROOT, rel);
  const to = join(OUT, rel);
  if (!existsSync(from)) return false;
  mkdirSync(dirname(to), { recursive: true });
  const stat = statSync(from);
  if (stat.isDirectory()) cpSync(from, to, { recursive: true });
  else copyFileSync(from, to);
  return true;
}

function ensureCss() {
  const dest = join(OUT, "css/styles.css");
  if (SEPARATE && copyOwned("css")) return "css copy từ repo";
  if (existsSync(dest) && !SEPARATE) return "css giữ nguyên";
  const src = join(ROOT, "src/styles.css");
  if (!existsSync(src)) {
    if (existsSync(join(ROOT, "css/styles.css")) && !existsSync(dest)) {
      copyOwned("css/styles.css");
      return "css copy";
    }
    return "không có css nguồn";
  }
  let css = readFileSync(src, "utf8");
  css = css.replace('@import "tailwindcss";', "");
  css = css.replace(/@theme \{[\s\S]*?\}\s*/, "");
  css = css.replace(/@layer base \{[\s\S]*?\}\s*/, "");
  css = css.replaceAll(
    "var(--font-sans)",
    '"Source Sans 3", "IBM Plex Sans", ui-sans-serif, system-ui, sans-serif',
  );
  css = css.replaceAll("var(--font-serif)", 'Fraunces, "Source Serif 4", ui-serif, Georgia, serif');
  css = `button:not(:disabled), [role="button"]:not(:disabled) { cursor: pointer; }\n` + css;
  css = css.replace(
    /button:not\(:disabled\), \[role="button"\]:not\(:disabled\) \{ cursor: pointer; \}\s*\}/,
    "button:not(:disabled), [role=\"button\"]:not(:disabled) { cursor: pointer; }\n",
  );
  mkdirSync(join(OUT, "css"), { recursive: true });
  writeFileSync(dest, css);
  return "css tạo lần đầu";
}

function copyImages() {
  if (!existsSync(IMG_SRC)) return 0;
  mkdirSync(join(OUT, "img"), { recursive: true });
  let n = 0;
  for (const file of readdirSync(IMG_SRC)) {
    if (!/\.(jpg|jpeg|png|webp|svg)$/i.test(file)) continue;
    const from = join(IMG_SRC, file);
    const to = join(OUT, "img", file);
    if (!existsSync(to) || newerThan(statSync(from).mtimeMs, to)) {
      copyFileSync(from, to);
      n++;
    }
  }
  return n;
}

const posts = loadPosts();
mkdirSync(join(OUT, "bai"), { recursive: true });
mkdirSync(join(OUT, "js"), { recursive: true });

if (SEPARATE) {
  copyOwned("index.html");
  copyOwned("favicon.svg");
  copyOwned("js");
}

const catalog = posts.map(({ body, mdPath, mdMtime, ...meta }) => meta);
writeFileSync(join(OUT, "posts.json"), JSON.stringify(catalog, null, 2) + "\n");

let wroteArticles = 0;
let skippedArticles = 0;
for (const post of posts) {
  if (slugFlag && post.slug !== slugFlag) continue;
  const dest = join(OUT, "bai", `${post.slug}.html`);
  const should = forceAll || SEPARATE || slugFlag === post.slug || newerThan(post.mdMtime, dest);
  if (!should) {
    skippedArticles++;
    continue;
  }
  writeFileSync(dest, articleHtml(post));
  wroteArticles++;
}

const indexPath = join(OUT, "index.html");
const indexNote = existsSync(indexPath)
  ? SEPARATE
    ? "index.html copy từ repo (không đè file gốc)"
    : "index.html GIỮ NGUYÊN (sửa tay không bị đè)"
  : writeIfMissing(indexPath, defaultIndex())
    ? "index.html tạo lần đầu"
    : "index.html GIỮ NGUYÊN (sửa tay không bị đè)";

if (SEPARATE) {
  if (!existsSync(join(OUT, "js/theme.js"))) writeFileSync(join(OUT, "js/theme.js"), THEME_JS);
  if (!existsSync(join(OUT, "js/posts.js"))) writeFileSync(join(OUT, "js/posts.js"), POSTS_JS);
} else {
  writeIfMissing(join(OUT, "js/theme.js"), THEME_JS);
  writeIfMissing(join(OUT, "js/posts.js"), POSTS_JS);
}

const cssNote = ensureCss();
const imgNote = copyImages();
const favSrc = existsSync(join(ROOT, "public/favicon.svg"))
  ? join(ROOT, "public/favicon.svg")
  : join(ROOT, "favicon.svg");
if (existsSync(favSrc) && !existsSync(join(OUT, "favicon.svg"))) {
  copyFileSync(favSrc, join(OUT, "favicon.svg"));
}
writeFileSync(join(OUT, ".nojekyll"), "");

console.log(
  [
    `out: ${OUT}`,
    `posts.json: ${catalog.length} bài`,
    `html bài: +${wroteArticles} (bỏ qua ${skippedArticles} bài không đổi)`,
    indexNote,
    cssNote,
    `ảnh mới/cập nhật: ${imgNote}`,
  ].join("\n"),
);
